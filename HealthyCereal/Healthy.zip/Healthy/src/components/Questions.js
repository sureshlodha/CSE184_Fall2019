import React from "react";
import "./Questions.css";
import Slider from 'react-input-slider';

class Questions extends React.Component {
    constructor(props) {
        super(props);
        this.handleChange = this.handleChange.bind(this);
        this.labelStyle = this.labelStyle.bind(this);
        this.state = {
            calories: 0,
            sugar: 0,
            fat: 0,
            sodium: 0,
            protein: 0,
            fiber: 0,
            vitamins: 0,
        };
      }

      handleChange(name, x) {
        const newState = Object.assign({}, this.state, {
            [name]:x
        });
        this.setState(newState)
        // console.log(newState);
        this.props.onSubmitQs(newState);
      }

      labelStyle(index) {
          return {
              color: this.props.sliderColors[index]
          }
      }

    
      render(props) {
        return (
            <div>
                <form>
                    {
                        this.props.questions.map((q, index) => {
                            return(
                                <div className="question-and-weights">
                                    <div className="question" key={index}>
                                        <div className="question-label">How important is it for your cereal to have <span style={this.labelStyle(index)}>{q.label}?</span></div>
                                        <div className="radio-group">
                                            <div className="slider">
                                                <Slider
                                                    axis="x"
                                                    xmin={0}
                                                    xmax={100}
                                                    x={this.state[q.name]}
                                                    onChange={({ x }) => {
                                                        // this.setState(state => ({ ...state, [q.name]:x }));
                                                        this.handleChange(q.name, x);
                                                        }
                                                    }
                                                    styles={{
                                                        active: {
                                                            backgroundColor: this.props.sliderColors[index]
                                                        }
                                                    }}
                                                />
                                            </div>                                 
                                            <div className="options">
                                                <div className="option">Not at all important</div>
                                                {/* <div className="option">Slightly important</div> */}
                                                <div className="option">Important</div>
                                                {/* <div className="option">Fairly important</div> */}
                                                <div className="option">Very important</div>
                                            </div>
                                        </div>
                                    </div>
                                    <div className="weights">
                                        {Math.round(this.props.gains[index]*10000)/100}%
                                    </div>
                                </div>
                            )
                        })
                    }
                </form>
            </div>
        );
      }
}

export default Questions;
