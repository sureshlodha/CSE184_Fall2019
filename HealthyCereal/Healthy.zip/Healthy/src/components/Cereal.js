import React from "react";
import "./Cereal.css"

function Cereal(props) {
  return (
    <div className="cereal">
      <div className="cereal-overview">
        <div>{props.cereal.name}</div>
        <div>Health score: {Math.round(props.cereal.health_score)}</div>
      </div> 
      <div className="nutrition-facts">
        <div>
          <div>Calories</div>
          <div className="nutrition">{props.cereal.calories}</div>
        </div>
        <div>
          <div>Sugars</div>
          <div className="nutrition">{props.cereal.sugars}</div>
        </div>
        <div>
          <div>Fat</div>
          <div className="nutrition">{props.cereal.fat}</div>
        </div>
        <div>
          <div>Protein</div>
          <div className="nutrition">{props.cereal.protein}</div>
        </div>
        <div>
          <div>Fiber</div>
          <div className="nutrition">{props.cereal.fiber}</div>
        </div>
        <div>
          <div>Vitamins</div>
          <div className="nutrition">{props.cereal.vitamins}</div>
        </div>
        <div>
          <div>Sodium</div>
          <div className="nutrition">{props.cereal.sodium}</div>
        </div>
      </div>
    </div>
  );
}

export default Cereal;