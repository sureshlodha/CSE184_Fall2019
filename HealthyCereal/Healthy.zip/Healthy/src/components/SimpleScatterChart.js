import React, { PureComponent } from 'react';
import {
  ScatterChart, Scatter, XAxis, YAxis, CartesianGrid, Tooltip, Cell
} from 'recharts';
import { scaleOrdinal } from 'd3-scale';
import { schemeCategory10 } from 'd3-scale-chromatic';
import './SimpleScatterChart.css';

const colors = scaleOrdinal(schemeCategory10).range();

const CustomTooltip = ({ active, payload, label }) => {
  if (active) {
    console.log(payload[0]);
    // name = payload[0].name;
    // cereal = payload[0].payload;

    return (
      <div className="custom-tooltip">
        <p className="label">{payload[0].payload.name}</p>
        <p className="label">{`${payload[0].name} : ${payload[0].payload[payload[0].name]}`}</p>
      </div>
    );
  }

  return null;
};

export default class SimpleScatterChart extends PureComponent {
  render() {
    return (
      <ScatterChart
        width={800}
        height={300}
        margin={{
          top: 20, right: 20, bottom: 20, left: 60,
        }}
      >
        <CartesianGrid />
        <YAxis label={{value: this.props.category, dx: -40}} type="number" dataKey={this.props.category} name={this.props.category} unit="" />
      <Tooltip cursor={{ strokeDasharray: '3 3' }} content={<CustomTooltip />} />
        <Scatter name={"Cereal "+this.props.category} data={this.props.cereals} fill="#8884d8">
          {
            this.props.cereals.map((entry, index) => <Cell key={`cell-${index}`} fill={colors[index % colors.length]} />)
          }
        </Scatter>
      </ScatterChart>
    );
  }
}