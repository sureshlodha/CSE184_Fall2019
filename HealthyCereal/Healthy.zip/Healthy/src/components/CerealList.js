import React from "react";
import Cereal from "./Cereal"

function CerealList(props) {
  return (
    <div>{props.cereals.map(c => <Cereal cereal={c}/>)}</div>
  );
}

export default CerealList;