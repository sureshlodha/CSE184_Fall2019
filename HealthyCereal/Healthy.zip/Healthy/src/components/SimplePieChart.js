import React, { PureComponent } from 'react';
import {
  PieChart, Pie, Legend, Tooltip, Cell
} from 'recharts';

const COLORS = ['#0088FE', '#00C49F', '#FFBB28', '#FF8042'];

const RADIAN = Math.PI / 180;

const renderCustomizedLabel = ({
  cx, cy, midAngle, innerRadius, outerRadius, percent, index, title,
}) => {
  const radius = innerRadius + (outerRadius - innerRadius) * 0.5;
  const x = cx + (radius * Math.cos(-midAngle * RADIAN))*2.5;
  const y = cy + (radius * Math.sin(-midAngle * RADIAN))*2.5;

  return (
    <text x={x} y={y} cy={-20} fill="grey" textAnchor={x > cx ? 'start' : 'end'} dominantBaseline="central">
      {`${(percent * 100).toFixed(0)}%`}
      {/* {title} */}
    </text>
    
  );
};


export default class SimplePieChart extends PureComponent {
  

  render(props) {
    return (
      <PieChart width={350} height={320}>
        <Pie fill={this.props.data[0].color} dataKey="value" nameKey="title" legendType="square" isAnimationActive={false} data={this.props.data} cx={190} cy={150} outerRadius={80} 
        label= {renderCustomizedLabel}>
        >
          {
            this.props.data.map((entry, index) => <Cell fill={this.props.data[index].color} key={this.props.data[index].title}/>)
          }
        </Pie>
        {/* <Pie dataKey="value" data={data02} cx={500} cy={200} innerRadius={40} outerRadius={80} fill="#82ca9d" /> */}
        <Tooltip />
      </PieChart>
    );
  }
}
