Aravind Patnam, Jeremy Tan, Timothy Le
CSE184 Final Project

# trending-here-trending-there
An analysis of Youtube trends

Github:
https://github.com/akpatnam25/trending-here-trending-there

# view notebook here (use Chrome for best experience)
https://nbviewer.jupyter.org/github/akpatnam25/trending-here-trending-there/blob/master/FinalTrendingHereTrendingThere_v2.ipynb
