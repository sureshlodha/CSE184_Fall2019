#import libraries
import math
import time

#strings of top 20 openings
openings = ['e4','d4','c4','Nf3','g3','b3','f4','Nc3','b4','e3','d3','c3','a3','g4','h3','h4','Nh3','a4','f3','Na3']

#dict where key is opening move and value is list [int,int,dict]
#data[open][0] is total number of games opening with open
#data[open][1] is sum of white-black elo differentials for games where opening is open
#data[open][2] is dict where keys are game lengths in move count and values are [int,int,int,int] 
	#The 4-dimensional list above is total number of each outcome by length and opening => [white,black,draw,unknown]
	#Ex: data[open][2][length][0] is the count of games of where opening move is open, number of moves is length, and white won
data = {}

t1 = time.time()
with open('data/game_list.csv', 'r') as fp: #for each game
	line = fp.readline() #read and ignore header row
	line = fp.readline()#read first game
	
	while line: #while end of file isn't reached
		row = line.split(',') #split on comma to get columns
		
		moves = row[-2].split() #get the whitespace-delimited list of moves in algebraic notation
		
		length = math.ceil(len(moves)/3) #get the number of moves
		
		#if there aren't any moves, skip this game
		if len(moves) < 2: 
			line = fp.readline()
			continue
		
		#get result string, one of '1-0', '0-1', '1/2-1/2', '*'
		result = row[-1].strip()
		
		#get elos and calculate differential
		whiteElo = int(row[-4])
		blackElo = int(row[-3])
		eloDiff = whiteElo - blackElo
		
		opening = moves[1] #get the string for the opening move
		
		#if white won
		if result == '1-0':
			print('white')
			#if the opening isn't in the top 20 most common, set it to 'other'
			if opening not in openings:
				opening = 'other'
			#if we haven't seen this opening before, add a dictionary entry for it
			if opening not in data:
				data[opening] = [1, eloDiff, {}] #since we haven't seen it before, game count is one, total elo diff is eloDiff, and distribution dict is empty
				data[opening][2][length] = [1, 0, 0, 0] #add the first entry to the distribution dict (result = '1-0' so white won)
			#if we have seen it, update the dictionary entry
			else:
				data[opening][0] = data[opening][0] + 1 #increment the game count by 1
				data[opening][1] = data[opening][1] + eloDiff #add eloDiff to the total elo differntial for this move and length
				#if we haven't seen this length with this opening, make a new dist dict entry for this length
				if length not in data[opening][2]:
					data[opening][2][length] = [1, 0, 0, 0]
				#if we have seen this length, update the distribution dict entry for this length
				else:
					data[opening][2][length][0] = data[opening][2][length][0] + 1 #we use the 0th entry for this distribution dict since white won
				
		#if black won; look at comments for white because it's the same
		elif result == '0-1':
			print('black')
			if opening not in openings:
				opening = 'other'
				
			if opening not in data:
				dist_dict = {}
				data[opening] = [1, eloDiff, dist_dict]
				data[opening][2][length] = [0, 1, 0, 0]
			else:
				data[opening][0] = data[opening][0] + 1
				data[opening][1] = data[opening][1] + eloDiff
				if length not in data[opening][2]:
					data[opening][2][length] = [0, 1, 0, 0]
				else:
					data[opening][2][length][1] = data[opening][2][length][1] + 1
				
		#if game was a draw; look at comments for white for more info
		elif result == '1/2-1/2':
			print('draw')
			if opening not in openings:
				opening = 'other'
				
			if opening not in data:
				data[opening] = [1, eloDiff, {}]
				data[opening][2][length] = [0, 0, 1, 0]
			else:
				data[opening][0] = data[opening][0] + 1
				data[opening][1] = data[opening][1] + eloDiff
				if length not in data[opening][2]:
					data[opening][2][length] = [0, 0, 1, 0]
				else:
					data[opening][2][length][2] = data[opening][2][length][2] + 1
				
		#if outcome was unknown; check previous comments for info
		elif result == '*':
			print('white')
			if opening not in openings:
				opening = 'other'

			if opening not in data:
				data[opening] = [1, eloDiff, {}]
				data[opening][2][length] = [0, 0, 0, 1]
			else:
				data[opening][0] = data[opening][0] + 1
				data[opening][1] = data[opening][1] + eloDiff
				if length not in data[opening][2]:
					data[opening][2][length] = [0, 0, 0, 1]
				else:
					data[opening][2][length][3] = data[opening][2][length][3] + 1
				
		#if something else is in the result column, throw an error
		else:
			print('ERROR! UNKNOWN RESULT: {}'.format(result))
			exit(0)
	
		#read in the next game
		line = fp.readline()
t2 = time.time()

print('Time to count game results: {}. Writing...'.format(t2-t1)) #print runtime to console
			
t3 = time.time()
#for each opening, make a distribution file and add to elo file
for opening in openings:
	path = 'data/{}_dists.csv'.format(opening)
	with open(path, 'w') as fp: #make new csv for length/outcome distributions for this opening
		fp.write('length,white,black,draw,unknown\n') #header row
		#for each length in the distribution dict for this opening
		for key in data[opening][2]:
			fp.write('{},{},{},{},{}\n'.format(key, data[opening][2][key][0], data[opening][2][key][1], data[opening][2][key][2], data[opening][2][key][3])) #write outcome counts
			
	with open('data/avg_elo_diff_by_opening.txt', 'a') as fp: #append to the average elo diff file
		fp.write('{}: {} total elo differential over {} games; {} is average differential'.format(opening, data[opening][1], data[opening][0], data[opening][1]/data[opening][0])) #add a new line for this opening
t4 = time.time()
		
print('Time to write: {}. Thank you for using this shitty code.'.format(t4-t3)) #print writing time to console