There are a number of Python files in this compressed folder. They can be ignored because 
all of the code was the pasted into brett_sargen.ipynb. They were included in case the reader 
would like to see the actual files that were ran for scraping and wrangling tasks. Data

IMPORTANT NOTE: running the scraping and wrangling cells in brett_sargent.ipynb will take a
lot of time and will use well over 10GB of space. It would be safe to allow for 15GB of space
and several hours of time. Alternatively, my data can be found in the Google Drive linked in
data.txt.

IMPORTANT NOTE: To download the pgn files, you need to login to the database. I have provided my
login information in api_key.txt so that the teaching staff doesn't need to make an account to run 
the scraping code. This login information must be entered on line 9 of the first cell in the ipynb 
file. 

Also, note that the Github repository at the link included in the ipynb file doesn't contain anything
not in this zip folder.

