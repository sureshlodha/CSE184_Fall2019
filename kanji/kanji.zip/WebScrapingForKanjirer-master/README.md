Running order:

Run the questions 1 through 4 in order, each question has its own README.md with order information. 

Information about questions and results are in "CSE 184 final project step 3.pdf"

Contributions:

contributions.pdf

Website:

http://awesomekanji.cf/

GitHub:

https://github.com/DustinSeltz/WebScrapingForKanjirer