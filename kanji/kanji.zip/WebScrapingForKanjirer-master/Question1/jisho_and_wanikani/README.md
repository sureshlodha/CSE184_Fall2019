# Scrape wanikani level and data from Jisho.org


### Wanikani level
scrape wanikani level from https://www.wanikani.com/

### Jisho data
scrape Jisho data from http://jisho.org/

### Build
```
pip install -r requirements.txt
```

### Run
```
python3 main.py
```