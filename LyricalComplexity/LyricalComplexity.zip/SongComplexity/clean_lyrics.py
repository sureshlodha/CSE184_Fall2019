import json

with open('all_lyrics.json', 'r') as f:
    all_lyrics = json.load(f)

# clean the lyrics by taking out punctuation and replacing slang like "ridin'" with "riding"
def clean_word(word):
    word = word.lower()
    word = word.replace(',', '')
    word = word.replace('[', '')
    word = word.replace(']', '')
    word = word.replace('(', '')
    word = word.replace(')', '')
    word = word.replace('.', '')
    word = word.replace(':', '')
    word = word.replace('"', '')
    word = word.replace('?', '')
    word = word.replace('!', '')
    word = word.replace('&', 'and')
    
    if len(word) > 2:
        if word[-1] == "'":
            return word[:-1] + 'g'
    return word

# clean each line by cleaning all the words in it
def clean_line(line):
    new_line = ' '.join(map(clean_word, line.split(' ')))
    new_line.encode('utf-8')
    return new_line

new_songs = {}

# clean the lyrics for all the songs in the json
for i in range(1960, 2019):
    for song in all_lyrics[str(i)]:
        temp = []
        for verse in song.get('verses', []):
            cleaned_verse = list(map(clean_line, verse))
            if cleaned_verse:
                temp.append(cleaned_verse)
        song['verses'] = temp

with open('all_lyrics_cleaned.json', 'w+') as f:
    json.dump(all_lyrics, f, indent=4, ensure_ascii=False)