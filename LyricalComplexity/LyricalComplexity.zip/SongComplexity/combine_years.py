import json
from contextlib import ExitStack

year_range = range(1971, 2019) # 2018 + 1

# we didn't include all the individual lyric files because there are about 50 of them
# and all the lyrics are already in all_lyrics.json, but we scraped each year of lyrics
# into their own json and then after all that was done, we combined them all into 
# all_lyrics.json.
# we also do not include all_lyrics.json, only all_lyrics_cleaned.json, which was cleaned in
# the clean_lyrics.py file.
lyric_file_names = ['lyrics_{}.json'.format(year) for year in year_range]
lyric_file_names.append('lyrics_2012_pt1.json')
lyric_file_names.append('lyrics.json')

all_lyrics = {}

# ExitStack() let us open multiple files at once so we can load them and append them to all_lyrics
with ExitStack() as stack:
    files = [stack.enter_context(open(fname)) for fname in lyric_file_names]
    for file in files:
        loaded = json.load(file)
        all_lyrics.update(loaded)

# for some reason ExitStack wouldn't open the 1993 json properly, so we're manually append it
# to all_lyrics here
with open('lyrics_1993.json') as f:
    all_lyrics.update(json.load(f))

# dump all_lyrics in the json with an indent for readability
with open('all_lyrics.json', 'w+') as f:
    json.dump(all_lyrics, f, indent=4)