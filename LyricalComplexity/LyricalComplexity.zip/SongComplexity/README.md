Song Complexity of Popular Music
Danilo Radovic, Simon Bukin, Enes Yazgan

----------------------

Installation/Code

All of our code was written in Python 3.6+, so versions of Python below are not guaranteed to work.

Instructions for environment:
Our code uses a variety of libraries, so the following are instructions for setting up a virtual environment with our dependencies.

1. Create a new virtual environment using venv, which is built into Python.

python3 -m venv env

This creates a new virtual environment in the current directory called 'env'

2. Activate the environment

source env/bin/activate

Now that the virtual environment is active, we can install dependencies

3. Install proper dependencies

We have provided a 'requirements.txt' file that contains our dependencies. They can all be installed using the following command, while you are within a virtual environment:

pip install -r requirements.txt

All necessary dependencies should be installed and ready to go.

----------------------

File/Folder Breakdown:

Note: We originally had a JSON for each year of lyric data, which we then combined multiple times over lots of iterations into our final all_lyrics_cleaned.json. You may see references to these intermediary files in some of the code, but the version that was used for visualization and analysis was all_lyrics_cleaned.json

/jupyter_notebook_pdfs/
This folder contains all of our Jupyter notebooks in PDF form, in case there are any issues running them.

/visualization/
This folder contains images of our visualizations. These images are taken from our visualization notebooks (Simon_Bukin_3.ipynb and Simon_Bukin_2.ipynb)

all_lyrics_cleaned.json
This is a JSON file containing our master dataset of cleaned lyrics. It contains songs from 1960-2018, as well as their names, artists, number of words, verses, genre, length, density and similar verse score.

clean_lyrics.py
This file shows our cleaning process for song lyrics.

combine_years.py
This file contains our process of combining our individual year lyric files into 1 master lyric file. We originally had each year of lyrics stored in its own individual JSON file, so this process was necessary to combine all the different files into 1.

complexity.py
This file contains a variety of methods that were used to calculate our complexity metrics. These include the similar verse score as well as unique words.

hot100_years.csv
This CSV contains the names and artists associated with songs that were on the Billboard 100 for each given year.

Danilo_Radovic_3.ipynb
This Jupyter notebook contains our interactive, animated plot made in Plotly.

lyric_scraping.py
This file contains our main scraping code, including making requests to AZLyrics, cleaning the lyrics, and saving them to a JSON file.

lyric_dataframe.json
This JSON file is a Pandas DataFrame containing our final dataset. This file can be easily loaded into Pandas and inspected.

Danilo_Radovic_1.ipynb
This Jupyter notebook is used to convert our master JSON file into a Pandas DataFrame with its associated fields (unique_words, verse similarity, etc) and export it to another JSON file.

Danilo_Radovic_2.ipynb
This Jupyter notebook contains the code that generates our visualizations.

update_json.py
This file updates our master JSON with complexity attributes.

wiki_scraping.py
This file contains our scraping for the Wikipedia Billboard Top 100 chart from 1960-2018

writeup.pdf
This PDF contains our abstract project overview and writeup of the project as a whole.

----------------------