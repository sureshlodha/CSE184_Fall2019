import requests, time, csv, json, random
from bs4 import BeautifulSoup

root_url = 'https://www.azlyrics.com/lyrics/'

# clean a song title into what the az lyrics url would accept
def clean_artist(artist):
    new_artist = artist.lower()
    new_artist = new_artist.replace(' ', '')
    new_artist = new_artist.replace('.', '')
    new_artist = new_artist.replace(',', '')
    new_artist = new_artist.replace("'", '')
    new_artist = new_artist.replace('"', '')
    new_artist = new_artist.replace('(', '')
    new_artist = new_artist.replace(')', '')
    new_artist = new_artist.replace('?', '')
    new_artist = new_artist.replace('!', '')
    if new_artist.startswith('the'):
        new_artist = new_artist[3:]
    if new_artist == 'jay-z':
        new_artist = 'jayz'

    return new_artist

# clean an artist name into what the az lyrics url would accept
def clean_song_name(song_name):
    new_song_name = song_name.lower()
    new_song_name = new_song_name.replace(' ', '')
    new_song_name = new_song_name.replace('.', '')
    new_song_name = new_song_name.replace(',', '')
    new_song_name = new_song_name.replace("'", '')
    new_song_name = new_song_name.replace('"', '')
    new_song_name = new_song_name.replace('(', '')
    new_song_name = new_song_name.replace(')', '')
    new_song_name = new_song_name.replace('?', '')
    new_song_name = new_song_name.replace('!', '')

    return new_song_name

def scrape_song(song_name, artist):
    # Makes 1 request for the specific song by a given artist, returning the lyrics
    cleaned_artist = clean_artist(artist)
    cleaned_song_name = clean_song_name(song_name)
    request_url = '{}{}/{}.html'.format(root_url, cleaned_artist, cleaned_song_name)
    page = requests.get(request_url)

    # if valid page
    if page.status_code == 200:
        soup = BeautifulSoup(page.content, 'html.parser')
        # the MusixMatch image only shows up on lyric pages, so this is how we are
        # determining if the lyric webpage exists
        musix = str(soup.select('.footer-wrap > div:nth-child(1) > div:nth-child(1) > img:nth-child(2)'))
        if musix:
            if 'MusixMatch' in musix:
                # get div containing all lyrics
                lyrics_div = soup.select('div.col-xs-12:nth-child(2) > div:nth-child(8)')

                if lyrics_div:
                    lyrics = lyrics_div[0].get_text()
                else:
                    lyrics_div = soup.select('div.col-xs-12:nth-child(2) > div:nth-child(10)')
                    try:
                        lyrics = lyrics_div[0].get_text()
                    except:
                        return {}
                

                song = {'title': song_name,
                        'artist': artist,
                        'num_words': 0, # start as list of words to avoid duplicates, then 'set' it
                        'num_verses': 0,
                        'verses': []
                        }

                verses = [verse for verse in lyrics.split('\n\n')]
                song['verses'] = []
                song['num_verses'] = len(verses)

                for verse in verses:
                    # only keep non-empty stripped strings as lines
                    lines = [line.strip() for line in verse.split('\n') if line.strip() != '']
                    song['verses'].append(lines)
                    for line in lines:
                        words = line.split()
                        song['num_words'] += len(words)
                return song
    return {}

# lyrics dictionary structure:
#  { 1960:[ { 'artist':'blah',
#             'title':'blah',
#             'words':'500',
#             'length':'3:40',
#             'num_verses':'4',
#             'genre':'blah',
#             'verses':[['line', 'line', 'line'], ['line', 'line', 'line']],
#           },
#         ],
#  }

def scrape_songs(year_range):
    # convert year range to list of year offsets
    years = [i for i in range(year_range[0] - 1959, year_range[1] - 1959 + 1)]
    lyrics = {}

    with open('hot100_years.csv', 'r') as csv_file:
        csv_reader = csv.reader(csv_file)
        # starts in 1960
        for year_offset, row in enumerate(csv_reader):
            if year_offset in years:
                year = int(row[0])
                year_songs = []

                new_data = {}

                for j in range(1, len(row)):
                    # entry in the CSV
                    entry = row[j]
                    slash_seperator = entry.find('//')
                    star_seperator = entry.find('**')
                    # get the title and artist from the CSV so the song's lyrics can be scraped
                    title = entry[:slash_seperator]
                    artist = entry[slash_seperator + 2:star_seperator]

                    song = scrape_song(title, artist)
                    if song:
                        year_songs.append(song)
                    time.sleep(3)  # be nice to the server
                    lyrics[year] = year_songs

                    # dump the lyrics for all songs in the current year in a new file like 'lyrics_1960.json'
                    new_data.update(lyrics)
                    with open('lyrics_{}.json'.format(1959 + year_offset), 'w+') as new_file:
                        json.dump(new_data, new_file, indent=4)

year_range = (1960, 2018)
scrape_songs(year_range)