# scraping wikipedia from 1959 to 2018
import requests, time, csv
from bs4 import BeautifulSoup

hot100_years = open('hot100_years.csv', 'w', newline='')
csv_writer = csv.writer(hot100_years)
domain = 'https://en.wikipedia.org'

# remove quotations on either side of the song title
def clean_title(title):
    return title[1:len(title) - 1]

# remove any features and "and" words/artists -> in that case just keep the first artist
def clean_artist(artist):
    new_artist = artist
    
    feat = new_artist.find(' featuring')
    if feat != -1:
        new_artist = new_artist[:feat]

    comma = new_artist.find(',')
    if comma != -1:
        new_artist = new_artist[:comma]

    and_artist = new_artist.find('and')
    if and_artist != -1:
        return new_artist[:and_artist]

    return new_artist

# classify the genre into either rock, rap, pop, or other
def clean_genre(genre):
    new_genre = genre.lower()
    if new_genre.find('rock') != -1:
        return 'Rock'
    if new_genre.find('rap') != -1 or new_genre.find('hip') != -1 or new_genre.find('hop') != -1 or new_genre.find('r&b') != -1:
        return 'Rap'
    if new_genre.find('pop') != -1 or new_genre.find('easy') != -1:
        return 'Pop'
    return 'Other'

# scrape the wikipedia page for a song, getting the genre and song duration
def scrape_song(url):
    page = requests.get(url)
    soup = BeautifulSoup(page.content, 'html.parser')

    category = soup.find('td', class_='category')
    if not category:
        genre = ''
    else:
        genre_link = category.find('a')
        if not genre_link:
            genre = category.get_text()
        else:
            genre = genre_link.get_text()

    duration = soup.find('span', class_='duration')
    # if there's no length, put '0' as a placeholder
    if not duration:
        length = '0'
    else:
        minutes = duration.find('span', class_='min').get_text()
        seconds = duration.find('span', class_='s').get_text()
        length = minutes + ':' + seconds

    # return as a pair
    return (length, genre)

def scrape_chart(year, url):
    page = requests.get(url)
    soup = BeautifulSoup(page.content, 'html.parser')
    table = soup.find('table', class_='wikitable')
    # first row is descriptors not actual titles/artists
    rows = table.find_all('tr')
    rows = rows[1:]
    
    # first column of the CSV are the years themselves
    output_row = [str(year)]

    for row in rows:
        entries = row.find_all('td')
        title_position = 1
        artist_position = 2
        
        # some wiki pages don't include the song number as a td entry
        if len(entries) == 2:
            title_position = 0
            artist_position = 1

        title = clean_title(entries[title_position].get_text())

        artist = entries[artist_position].get_text()
        artist = artist[:len(artist) - 1]  # removing \n
        artist = clean_artist(artist)
        
        title_link = entries[title_position].find('a', href=True)
        if not title_link:
            length = 0
            genre = ''
        else:
            title_link = domain + title_link['href']
            time.sleep(2)  # be nice to the server
            # scrape the song for duration and genre
            # note: length is the same thing as song duration
            length, genre = scrape_song(title_link)
            time.sleep(2)
            genre = clean_genre(genre)

        # the format of the CSV song entries will be title//artist**length^^genre so pulling each
        # attribute when getting the lyrics will be easier to break apart
        output_song = str(title) + '//' + str(artist) + '**' + str(length) + '^^' + str(genre)
        output_row.append(output_song)

    csv_writer.writerow(output_row)

for year in range(1959, 2019):
    url = "https://en.wikipedia.org/wiki/Billboard_Year-End_Hot_100_singles_of_" + str(year)
    scrape_chart(year, url)
    time.sleep(7)  # be nice to the server

hot100_years.close()
