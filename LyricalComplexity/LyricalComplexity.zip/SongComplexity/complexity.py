import json

class Complexity:

	# return the number of unique words in a song by putting the list of words in a set
	def get_unique_words(self, song):
		verses = song.get('verses', [])
		all_words = []
		for verse in verses:
			for line in verse:
				all_words.extend(line.split(' '))
		return set(all_words)

	# density is the # of words divided by song length (duration)
	def song_density(self, num_words, song_length):
		# using a dummy value of 3 minutes if length is '0' aka the placeholder
		length = 0
		if song_length == '0':
			length = 180
		else:
			# length is in the form of minutes:seconds, we want to divide 
			colon = song_length.find(':')
			mins = song_length[0:colon]
			seconds = song_length[colon+1:]
			length = int(mins) * 60 + int(seconds)
		return int(num_words) / length

	def similarity_score(self, verse_one, verse_two):
		# the number of shared words between the two verses
		num_shared_words = len(verse_one & verse_two)
		# the combined length of the two verses
		combined_verse_length = len(verse_one) + len(verse_two)
		# the similarity score
		similarity = (num_shared_words * 2) / combined_verse_length
		
		return similarity

	# compare all verses to one another and sum all their similarity scores
	def compare_verses(self, verses):
		similar_verses_sum = 0

		verse_set = [set(item) for item in verses]
		for i1, item in enumerate(verse_set):
			for i2 in range(i1 + 1, len(verse_set)):
				similar_verses_sum += self.similarity_score(item, verse_set[i2])
			
		return similar_verses_sum