import json
import csv
from complexity import Complexity

# our complexity class handles the calculations for the unique_words, density, similar_verses_score attributes
complexity_class = Complexity()

with open('all_lyrics_cleaned.json', 'r') as lyric_file:
    lyric_data = json.load(lyric_file)

# give every song in the json the unique_words, density, similar_verses_score attributes
for i in range(1960, 2019):
    for song in lyric_data[str(i)]:
        print(song['artist'] + ' -- ' + song['title'])
        # higher unique words = more complex
        unique_words = len(complexity_class.get_unique_words(song))
        song['num_unique_words'] = unique_words
        # higher density = more complex
        density = complexity_class.song_density(song['num_words'], song['length'])
        song['density'] = density
        # lower similar verses score = more complex
        similar_verses_score = complexity_class.compare_verses(song['verses'])
        song['similar_verses_score'] = similar_verses_score

with open('all_lyrics_cleaned.json', 'w') as lyric_file:
    json.dump(lyric_data, lyric_file, indent=4)